# Routine — Android planner source project

This is a native Android starter project based on the Routine planner prototype. It is free/open source source code with no subscription or third-party SDK dependencies.

## Included
- Weekly schedule prefilled for the user's school week and Shabbat flexibility
- Add/edit/delete recurring schedule blocks (days are numbered Sunday=0 through Saturday=6)
- Per-block reminder minutes and Android alarm/notification scheduling
- Tasks and daily habits saved locally on the device
- Focus-friendly simple native interface
- Today's app-usage view via Android Usage Access
- Optional app limiter using Android Accessibility Service; rules are entered as `package.name=minutes`, separated by commas

## Important limitations
- This is a source project, not a prebuilt APK. It has not been compiled or tested on a device in this environment.
- The app blocker requires the user to explicitly enable Usage Access and the Routine accessibility service in Android Settings. The service can send a selected app to Home once its daily usage reaches its configured limit. Android usage reporting may be delayed and battery/vendor restrictions can affect alarms.
- This is a starter implementation. Before distributing publicly, it should be tested on multiple Android versions, add a more user-friendly app picker, improve accessibility disclosures, and validate alarm behavior on target devices.
- Friday and Saturday blocks are deliberately flexible; adjust them to actual Shabbat times.

## Build an APK with Android Studio
1. Install Android Studio on your Windows PC.
2. Open the `RoutineAndroid` folder as a project.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the generated APK location. Install it on your own device and grant only the permissions you want to use.

## Enable reminders and app limits
- Allow notifications when prompted.
- Allow exact alarms if Android asks.
- In Screen time, grant Usage Access to view app usage.
- To enforce package rules, enable the Routine accessibility service. Example rule: `com.instagram.android=60,com.google.android.youtube=45`.

No data is sent to a server; planner settings are stored in SharedPreferences on the device.

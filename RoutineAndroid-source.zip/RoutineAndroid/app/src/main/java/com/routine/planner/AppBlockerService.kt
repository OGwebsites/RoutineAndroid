package com.routine.planner

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.app.usage.UsageStatsManager
import java.util.Calendar

/** Optional blocker. Rules are package.name=minutes, separated by commas in SharedPreferences. */
class AppBlockerService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        val rules = Store.string(this, "block_rules").split(",").mapNotNull { rule ->
            val p = rule.trim().split("=")
            if (p.size == 2) p[0].trim() to (p[1].trim().toLongOrNull() ?: 0L) else null
        }
        val limit = rules.firstOrNull { it.first == pkg }?.second ?: return
        if (limit <= 0) return
        val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }.timeInMillis
        val end = System.currentTimeMillis()
        val usage = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        val used = stats.filter { it.packageName == pkg }.sumOf { it.totalTimeInForeground }
        if (used >= limit * 60_000L) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }
    override fun onInterrupt() {}
}

package com.routine.planner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {
    fun scheduleAll(context: Context) {
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val blocks = Store.blocks(context)
        val now = System.currentTimeMillis()
        blocks.forEach { block ->
            if (block.reminderMinutes <= 0 && block.name != "Wake up") return@forEach
            block.days.forEach { day ->
                val parts = block.start.split(":")
                val cal = Calendar.getInstance().apply {
                    set(Calendar.DAY_OF_WEEK, if (day == 0) Calendar.SUNDAY else day + 1)
                    set(Calendar.HOUR_OF_DAY, parts[0].toInt())
                    set(Calendar.MINUTE, parts[1].toInt() - if (block.name == "Wake up" && block.reminderMinutes <= 0) 0 else block.reminderMinutes)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    while (timeInMillis <= now) add(Calendar.DAY_OF_YEAR, 7)
                }
                val id = (block.id % 100000).toInt() * 10 + day
                val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", block.name).putExtra("id", id)
                val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                try { manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) } catch (_: SecurityException) { manager.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) }
            }
        }
    }
}

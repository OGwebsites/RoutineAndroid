package com.routine.planner

data class ScheduleBlock(
    val id: Long,
    val name: String,
    val start: String,
    val end: String,
    val category: String,
    val days: Set<Int>,
    val reminderMinutes: Int = 0
)
data class PlannerTask(val id: Long, val name: String, val day: Int, val time: String = "", var done: Boolean = false)
data class PlannerHabit(val id: Long, val name: String, val emoji: String = "✦")

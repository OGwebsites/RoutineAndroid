package com.routine.planner

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val days = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
    private val primary = Color.rgb(91,92,226)
    private lateinit var root: LinearLayout
    private var selectedDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
    private var tab = "Schedule"
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=Color.rgb(245,246,251);window.navigationBarColor=Color.WHITE;window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; AlarmScheduler.scheduleAll(this); requestNotificationPermission(); show() }
    override fun onResume() { super.onResume(); AlarmScheduler.scheduleAll(this) }
    private fun dp(n:Int)= (n*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=15f,bold:Boolean=false):TextView=TextView(this).apply{ text=s;textSize=size;setTextColor(Color.rgb(32,34,54));if(bold)setTypeface(typeface,1); setPadding(dp(2),dp(5),dp(2),dp(5)) }
    private fun button(s:String, action:()->Unit):Button=Button(this).apply{text=s;isAllCaps=false;setTextColor(Color.WHITE);backgroundTintList=android.content.res.ColorStateList.valueOf(primary);setOnClickListener{action()} }
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(231,232,242))}; elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)}}
    private fun show(){
        val scroll=ScrollView(this);root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(24));setBackgroundColor(Color.rgb(245,246,251))};scroll.addView(root);setContentView(scroll)
        root.addView(text("Routine.",29f,true));root.addView(text("A little structure. More room to live.",13f))
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(14))}
        listOf("Schedule","Tasks","Habits","Screen time").forEach{t->val b=Button(this).apply{text=t;isAllCaps=false;textSize=11f;setTextColor(if(tab==t)Color.WHITE else primary);backgroundTintList=android.content.res.ColorStateList.valueOf(if(tab==t)primary else Color.rgb(231,231,250));setOnClickListener{tab=t;show()}};nav.addView(b,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(2),0,dp(2),0)})};root.addView(nav)
        when(tab){"Schedule"->scheduleView();"Tasks"->tasksView();"Habits"->habitsView();else->screenView()}
        root.addView(text("Your data stays on this device. For app blocking, enable Usage access and the optional Accessibility service in Screen time.",11f))
    }
    private fun scheduleView(){
        root.addView(text("Weekly schedule",20f,true));val dayrow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        days.forEachIndexed{index,d->val b=Button(this).apply{text=d.take(3);isAllCaps=false;textSize=10f;setTextColor(if(selectedDay==index)Color.WHITE else primary);backgroundTintList=android.content.res.ColorStateList.valueOf(if(selectedDay==index)primary else Color.WHITE);setOnClickListener{selectedDay=index;show()}};dayrow.addView(b,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(1),0,dp(1),dp(8))})};root.addView(dayrow)
        val list=Store.blocks(this).filter{selectedDay in it.days}.sortedBy{it.start}
        root.addView(text("${days[selectedDay]}'s plan · ${list.size} blocks",14f,true))
        list.forEach{block->val c=card();c.addView(text("${block.start}–${block.end}",12f,true));c.addView(text(block.name,16f,true));c.addView(text("${block.category}${if(block.reminderMinutes>0)" · reminder ${block.reminderMinutes} min before" else ""}",12f));val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};val check=CheckBox(this).apply{text="Done today";isChecked=Store.checked(this@MainActivity,"${dateKey()}:$selectedDay:${block.id}");setOnCheckedChangeListener{_,checked->Store.setChecked(this@MainActivity,"${dateKey()}:$selectedDay:${block.id}",checked)}};row.addView(check);val edit=Button(this).apply{text="Edit";isAllCaps=false;setOnClickListener{editBlock(block)}};row.addView(edit);val del=Button(this).apply{text="Delete";isAllCaps=false;setOnClickListener{Store.saveBlocks(this@MainActivity,Store.blocks(this@MainActivity).filterNot{it.id==block.id});AlarmScheduler.scheduleAll(this@MainActivity);show()}};row.addView(del);c.addView(row);root.addView(c)}
        root.addView(button("＋ Add schedule block"){addBlock()});root.addView(button("Rebuild reminders"){AlarmScheduler.scheduleAll(this);toast("Reminders scheduled. Check alarm/notification permissions.")})
    }
    private fun addBlock(existing:ScheduleBlock?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(6),dp(16),0)}
        val name=EditText(this).apply{hint="Activity name";setText(existing?.name?:"")};val start=EditText(this).apply{hint="Start HH:MM";setText(existing?.start?:"19:00")};val end=EditText(this).apply{hint="End HH:MM";setText(existing?.end?:"19:45")};val category=EditText(this).apply{hint="Category (Coding, Study, Streaming…)";setText(existing?.category?:"Study")};val daysInput=EditText(this).apply{hint="Repeat days: 0=Sun … 6=Sat";setText(existing?.days?.sorted()?.joinToString(",")?:selectedDay.toString())};val reminder=EditText(this).apply{hint="Reminder minutes before (0 = none)";inputType=android.text.InputType.TYPE_CLASS_NUMBER;setText((existing?.reminderMinutes?:0).toString())}
        listOf(name,start,end,category,daysInput,reminder).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle(if(existing==null)"Add schedule block" else "Edit schedule block").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->try{val st=start.text.toString().trim();val en=end.text.toString().trim();require(st.matches(Regex("\\d{2}:\\d{2}"))&&en.matches(Regex("\\d{2}:\\d{2}")));require(st<en);val ds=daysInput.text.toString().split(",").map{it.trim().toInt()}.filter{it in 0..6}.toSet();require(ds.isNotEmpty());val list=Store.blocks(this);if(existing!=null)list.removeAll{it.id==existing.id};list.add(ScheduleBlock(existing?.id?:System.currentTimeMillis(),name.text.toString().ifBlank{"New activity"},st,en,category.text.toString().ifBlank{"Personal"},ds,reminder.text.toString().toIntOrNull()?:0));Store.saveBlocks(this,list);AlarmScheduler.scheduleAll(this);show();toast("Saved schedule block") }catch(_:Exception){toast("Check times and repeat days, then try again")}}.show()
    }
    private fun editBlock(b:ScheduleBlock){addBlock(b)}
    private fun tasksView(){root.addView(text("Tasks & homework",21f,true));val tasks=Store.tasks(this);tasks.forEach{t->val c=card();val cb=CheckBox(this).apply{text="${t.name}\n${days.getOrElse(t.day){"Any day"}} ${t.time}";isChecked=t.done;setOnCheckedChangeListener{_,v->t.done=v;Store.saveTasks(this@MainActivity,tasks)}};c.addView(cb);root.addView(c)};root.addView(button("＋ Add task"){val input=EditText(this).apply{hint="Homework or task"};AlertDialog.Builder(this).setTitle("New task").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Add"){_,_->if(input.text.isNotBlank()){tasks.add(PlannerTask(System.currentTimeMillis(),input.text.toString(),selectedDay));Store.saveTasks(this,tasks);show()}}.show()})}
    private fun habitsView(){root.addView(text("Daily habits",21f,true));val habits=Store.habits(this);habits.forEach{h->val c=card();val key="${dateKey()}:${h.id}";val cb=CheckBox(this).apply{text="${h.emoji}  ${h.name}";isChecked=Store.checked(this@MainActivity,key);setOnCheckedChangeListener{_,v->Store.setChecked(this@MainActivity,key,v)}};c.addView(cb);root.addView(c)};root.addView(button("＋ Add habit"){val input=EditText(this).apply{hint="e.g. Read for 30 minutes"};AlertDialog.Builder(this).setTitle("New habit").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Add"){_,_->if(input.text.isNotBlank()){habits.add(PlannerHabit(System.currentTimeMillis(),input.text.toString()));Store.saveHabits(this,habits);show()}}.show()})}
    private fun screenView(){
        root.addView(text("Screen-time control",21f,true));root.addView(text("Set rules as package.name=minutes, separated by commas. Example: com.instagram.android=60,com.google.android.youtube=45",13f));
        val rules=EditText(this).apply{hint="package.name=minutes";setText(Store.string(this@MainActivity,"block_rules"));minLines=2;gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE};root.addView(rules)
        root.addView(button("Save app limits"){Store.put(this,"block_rules",rules.text.toString());toast("Rules saved. Enable Usage access and Accessibility below.")})
        root.addView(button("Grant usage access"){startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))})
        root.addView(button("Enable app blocker accessibility service"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))})
        root.addView(button("Show today's app usage"){showUsage()})
        root.addView(text("Rules use Android package names. The optional accessibility service sends a limited app back to Home after its daily usage reaches the rule. Enable it only if you understand and want this behavior. Usage tracking can be delayed by Android.",12f))
    }
    private fun showUsage(){try{val mgr=getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager;val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val stats=mgr.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,cal.timeInMillis,System.currentTimeMillis()).filter{it.totalTimeInForeground>0}.sortedByDescending{it.totalTimeInForeground}.take(12);val lines=stats.joinToString("\n"){s->"${s.packageName}: ${s.totalTimeInForeground/60000} min"};AlertDialog.Builder(this).setTitle("Today's app usage").setMessage(lines.ifBlank{"No usage data yet. Grant Usage access and try again."}).setPositiveButton("OK",null).show()}catch(_:Exception){toast("Grant Usage access first")}}
    private fun dateKey()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    private fun requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),100);if(Build.VERSION.SDK_INT>=31){val am=getSystemService(ALARM_SERVICE) as AlarmManager;if(!am.canScheduleExactAlarms()){try{startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))}catch(_:Exception){}}}}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}

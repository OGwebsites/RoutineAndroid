package com.routine.planner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private const val PREF = "routine_data"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun string(c: Context, key: String, fallback: String = "") = prefs(c).getString(key, fallback) ?: fallback
    fun put(c: Context, key: String, value: String) { prefs(c).edit().putString(key, value).apply() }
    fun bool(c: Context, key: String, fallback: Boolean = false) = prefs(c).getBoolean(key, fallback)
    fun putBool(c: Context, key: String, value: Boolean) { prefs(c).edit().putBoolean(key, value).apply() }
    fun blocks(c: Context): MutableList<ScheduleBlock> {
        val raw = string(c, "blocks")
        if (raw.isBlank()) return defaultBlocks().toMutableList().also { saveBlocks(c, it) }
        return try { val a = JSONArray(raw); MutableList(a.length()) { i -> val o=a.getJSONObject(i); ScheduleBlock(o.getLong("id"),o.getString("name"),o.getString("start"),o.getString("end"),o.getString("category"),o.getJSONArray("days").let { arr -> (0 until arr.length()).map { arr.getInt(it) }.toSet() },o.optInt("reminder",0)) } } catch (_: Exception) { defaultBlocks().toMutableList() }
    }
    fun saveBlocks(c: Context, list: List<ScheduleBlock>) { val a=JSONArray(); list.forEach { b -> a.put(JSONObject().put("id",b.id).put("name",b.name).put("start",b.start).put("end",b.end).put("category",b.category).put("days",JSONArray(b.days.sorted())).put("reminder",b.reminderMinutes)) }; put(c,"blocks",a.toString()) }
    fun tasks(c: Context): MutableList<PlannerTask> { val raw=string(c,"tasks"); if(raw.isBlank()) return mutableListOf(PlannerTask(1,"Check homework and deadlines",0,"17:40"),PlannerTask(2,"Review Python notes",2,"18:00"),PlannerTask(3,"Prepare school bag",4,"21:15")).also{saveTasks(c,it)}; return try { val a=JSONArray(raw); MutableList(a.length()){i->val o=a.getJSONObject(i);PlannerTask(o.getLong("id"),o.getString("name"),o.getInt("day"),o.optString("time"),o.optBoolean("done"))} }catch(_:Exception){ mutableListOf() } }
    fun saveTasks(c:Context,list:List<PlannerTask>){val a=JSONArray();list.forEach{a.put(JSONObject().put("id",it.id).put("name",it.name).put("day",it.day).put("time",it.time).put("done",it.done))};put(c,"tasks",a.toString())}
    fun habits(c:Context): MutableList<PlannerHabit> { val raw=string(c,"habits"); if(raw.isBlank()) return mutableListOf(PlannerHabit(1,"Read for 30 minutes","📖"),PlannerHabit(2,"Practise Python","🐍"),PlannerHabit(3,"Practise דפ״ר","🧠"),PlannerHabit(4,"Prepare school bag","🎒")).also{saveHabits(c,it)};return try{val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);PlannerHabit(o.getLong("id"),o.getString("name"),o.optString("emoji","✦"))}}catch(_:Exception){mutableListOf()} }
    fun saveHabits(c:Context,list:List<PlannerHabit>){val a=JSONArray();list.forEach{a.put(JSONObject().put("id",it.id).put("name",it.name).put("emoji",it.emoji))};put(c,"habits",a.toString())}
    fun checked(c:Context, key:String)=prefs(c).getBoolean("check_$key",false)
    fun setChecked(c:Context,key:String,value:Boolean){prefs(c).edit().putBoolean("check_$key",value).apply()}
    fun defaultBlocks() = listOf(
        ScheduleBlock(1,"Wake up","06:10","06:20","Personal",(0..4).toSet()), ScheduleBlock(2,"Leave for the bus","06:45","06:50","School",(0..4).toSet(),5),
        ScheduleBlock(3,"School","07:00","17:10","School",setOf(0,1,3)), ScheduleBlock(4,"School","07:00","16:10","School",setOf(2,4)),
        ScheduleBlock(5,"Snack and rest","17:10","17:40","Rest",setOf(0,1,3)), ScheduleBlock(6,"Homework","17:40","18:30","Study",setOf(0,1,3)), ScheduleBlock(7,"Dinner","18:30","19:00","Food",setOf(0,1,3)), ScheduleBlock(8,"דפ״ר practice","19:00","19:30","דפ״ר",setOf(0,3)), ScheduleBlock(9,"Python coding","19:30","20:15","Coding",setOf(0,1,3)), ScheduleBlock(10,"Free time","20:15","20:45","Rest",setOf(0,1,3)),
        ScheduleBlock(11,"Read a book","20:45","21:15","Reading",(0..4).toSet()), ScheduleBlock(12,"Get ready for bed","21:15","21:45","Personal",(0..4).toSet()), ScheduleBlock(13,"Sleep","21:45","22:00","Sleep",(0..4).toSet()),
        ScheduleBlock(14,"Snack and rest","16:10","16:40","Rest",setOf(2,4)), ScheduleBlock(15,"Homework","16:40","17:30","Study",setOf(2,4)), ScheduleBlock(16,"Dinner","17:30","18:00","Food",setOf(2,4)), ScheduleBlock(17,"Python coding","18:00","19:00","Coding",setOf(2)), ScheduleBlock(18,"Streaming","19:00","20:30","Streaming",setOf(2)), ScheduleBlock(19,"דפ״ר practice","18:00","18:30","דפ״ר",setOf(4)), ScheduleBlock(20,"Python coding","18:30","19:30","Coding",setOf(4)), ScheduleBlock(21,"Free time / catch-up","19:30","20:30","Rest",setOf(4)), ScheduleBlock(22,"Optional study before Shabbat","14:30","15:00","Coding",setOf(5)), ScheduleBlock(23,"Flexible activity after Shabbat","20:30","21:00","Personal",setOf(6))
    )
}
